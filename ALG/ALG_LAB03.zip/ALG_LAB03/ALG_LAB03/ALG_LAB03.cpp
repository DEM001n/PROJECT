﻿
#include "BST.h"

int main() {
    BST<int> tree;

    auto comp = [](int a, int b) { return a < b; };

    measureExecutionTime([&]() {
        for (size_t i = 0; i < 1000; i++)
        {
            tree.insert(getRandomNumber(-500, 500), comp);
        }
        });
 

    measureExecutionTime([&]() {tree.display(); });

    std::cout << "Tree size: " << tree.getSize() << std::endl;
    std::cout << "Tree height: " << tree.getHeight() << std::endl;

    measureExecutionTime([&]() {tree.preOrderDisplay(); });

    measureExecutionTime([&]() {
        for (size_t i = 0; i < 500; i++)
        {


            BSTNode<int>* found = tree.search(getRandomNumber(-500, 500), comp);
            if (found) {
                std::cout << "Found node: ID:" << found->id << " Key:" << found->key << std::endl;
            }
            else {
                std::cout << "Node not found.\n";
            }
        }
        });
    

    measureExecutionTime([&]() {
        for (size_t i = 0; i < 1000; i++)
        {
            tree.deleteNode(getRandomNumber(-500, 500), comp);
        }
        });

    return 0;
}
